// JavaScript for adding some simple effects
document.addEventListener('DOMContentLoaded', function() {
    const content = document.querySelector('.content');
    content.style.opacity = 0;
    content.style.transition = 'opacity 2s';
    window.setTimeout(() => {
        content.style.opacity = 1;
    }, 500);
});
