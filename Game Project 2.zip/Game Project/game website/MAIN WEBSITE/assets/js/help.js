document.addEventListener('DOMContentLoaded', function() {
    const games = document.querySelectorAll('.game');
    games.forEach((game, index) => {
        game.style.opacity = 0;
        game.style.transform = 'translateY(20px)';
        game.style.transition = `opacity 0.6s ease ${index * 0.3}s, transform 0.6s ease ${index * 0.3}s`;
        setTimeout(() => {
            game.style.opacity = 1;
            game.style.transform = 'translateY(0)';
        }, 100);
    });
});
