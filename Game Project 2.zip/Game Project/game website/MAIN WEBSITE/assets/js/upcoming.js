document.addEventListener('DOMContentLoaded', function() {
    const games = document.querySelectorAll('.game');
    games.forEach((game, index) => {
        game.style.opacity = 0;
        game.style.transform = 'translateY(30px)';
        game.style.transition = `opacity 0.5s ease ${index * 0.2}s, transform 0.5s ease ${index * 0.2}s`;
        setTimeout(() => {
            game.style.opacity = 1;
            game.style.transform = 'translateY(0)';
        }, 100);
    });
});
